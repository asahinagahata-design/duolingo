/* Seed data. 水野優帆さん's profile comes ONLY from the 2026-10-17 lesson (Gemini notes + transcript):
   https://docs.google.com/document/d/1x1PVKb5gn_LkpED4HX2J8zPmZOMeJFCjcfdALBpvrZQ/edit
   Unknown values are left empty (null / ""). */
window.DET_SEED = function () {
  return {
    version: 1,
    students: [{
      id: "s_mizuno", name: "水野優帆", grade: "高3（18歳）",
      profileNote: "国際コースの高校（カナダ人講師、授業の約2/3が英語）。転校して1年余り。野球でアメリカの大学へ進学予定（今年5〜8月にアメリカのサマーリーグ参加）。卒業後もアメリカで働きたい。",
      startDate: "2026-10-17", deadline: "2027-01-31", weeks: null,
      deadlineNote: "スコア提出は1月末の予定（傳崎さんと「3か月で決まるといい」）。本当の締切は未確認（傳崎さんに確認）。遅くとも3月まで。5月にカナダ経由で渡米。",
      currentScore: 60, currentScoreDate: "2026-09-15", sub: { R: null, L: null, W: null, S: null },
      subNote: "4技能の数値は未記録（スコア表はLINEで共有済み）。本人談：リスニングが一番高かった。無料の公式練習テストは60〜80程度、本番後の1回は70〜80程度。",
      targetScore: 95, stretchScore: 100, minimumScore: 75,
      targetNote: "目標95（着地95のため100を狙う）。紹介された大学は最低がDET75（TOEFL34）、多くは85以上、95の大学もある。",
      weekdayMinutes: 120, weekendMinutes: null,
      studyTimeNote: "学校は16〜17時に終わる。平日2〜3時間は取れる（本人談）。休日の時間は未確認。",
      lessonsPerWeek: 1, lessonDay: "水", lessonTime: "20:30", lessonNote: "水曜はリハビリが夕方にあるため20:30開始。次回 10/21（水）20:30。",
      weakTypes: ["interactiveWriting", "readThenSpeak", "interactiveSpeaking", "readSelect", "interactiveListening", "writingSample", "speakPhoto"],
      weakNote: "単語が苦手（語彙に不安）。ライティング・スピーキングはお題の理解と、英語で何を書く／話すか組み立てるのが苦手。リスニングは速い・長いと感じる。文法は「なんとなく」。",
      grammarReview: true, phase1Weeks: 4,
      vocabBook: "ターゲット1900", vocabProgress: 300, dailyNewWords: 30, dailyNewWordsStretch: 50,
      vocabNote: "1か月で最初の300語（1日約10語）。今後は1日30語、いけたら50語。1周目は丁寧に、2周目以降は分からない語中心に、1日2〜3周（朝・夕・翌朝）。8〜9割正解で次の範囲へ。",
      testPolicy: "max", testPolicyNote: "本番は30日に2回まで。1月末まで約7回のチャンス（講師提案）。本人は「受けられる回数をマックス」と発言。費用面は次回以降に相談（未確定）。",
      interests: ["sports"],
      monthFocus: "10月：単語のベースアップ＋中学文法・文構造（＋長文の練習）／11月：スピーキング・ライティング重点（＋リーディング）。最初の約4週で基礎固め→得点アップ→最後は実戦。",
      instructor: "長畑旭飛", active: true
    }],
    data: {
      s_mizuno: {
        logs: [], practice: [], taskChecks: {}, weekNotes: {},
        mocks: [{ id: "m1", date: "2026-09-15", kind: "official", score: 60, low: null, high: null, sub: { R: null, L: null, W: null, S: null }, note: "受講前の本番。4技能の内訳は未記録" }],
        lessons: [{
          id: "l1", date: "2026-10-17", instructor: "長畑旭飛",
          content: "初回面談：自己紹介・留学の動機、目標（95、狙いは100）と締切（1月末提出予定）の確認。受験回数制限（30日に2回）と受験計画。10〜11月の学習方針。反復による単語の覚え方（忘却曲線、1日2〜3周）。",
          feedback: "今の単語の覚え方（1周目→意味を隠して確認→翌日復習）はほぼ正解。数を増やし、短い間隔で何度も出会うように。分からない点はどんどん質問を。全体の弱点や不安も意識して日々の作業を進める。",
          homework: "ターゲット1900で1日30語（いけたら50語）＋1日2〜3周の反復。毎日の単語の進捗を講師に報告。30語と50語の負担の違いを次回報告。",
          next: "10/21（水）20:30：単語チェック（ランダム出題）、教材確定・学習計画の立案。講師→教材リンク（文法書・DET公式単語帳・DETの教科書）送付。"
        }]
      }
    },
    settings: { role: "student", pin: "1234", deviceStudentId: "s_mizuno", instructorName: "長畑旭飛",
      llm: { useLLM: false, endpoint: "https://api.openai.com/v1/chat/completions", model: "", apiKey: "" } }
  };
};
